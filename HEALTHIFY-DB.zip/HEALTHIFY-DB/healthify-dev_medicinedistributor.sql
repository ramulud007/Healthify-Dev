-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: healthify-dev
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `medicinedistributor`
--

DROP TABLE IF EXISTS `medicinedistributor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicinedistributor` (
  `Id` varchar(255) NOT NULL,
  `City` varchar(255) DEFAULT NULL,
  `EmailId` varchar(255) DEFAULT NULL,
  `MobileNo` varchar(255) DEFAULT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Pincode` varchar(255) DEFAULT NULL,
  `RegisterDate` date DEFAULT NULL,
  `Street` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicinedistributor`
--

LOCK TABLES `medicinedistributor` WRITE;
/*!40000 ALTER TABLE `medicinedistributor` DISABLE KEYS */;
INSERT INTO `medicinedistributor` VALUES ('20230209161518424','Haridwar','bendichealthcare@gmail.com','9876543210','Bendic Health Care Pvt. Ltd.','49403','2022-02-05','Plot No.-61, Sidcul, Bahardrabad Highway, Mahadevpuram Colony, Haridwar -49403'),('20230209161518425','Goa','gaiapharmaceutical@gmail.com','9876543211','Gaia Pharmaceutical Trade','403801','2022-02-05','G-14, Quatro D Commercial, Nr. Keshav Smruti School, International Airport Road, Dabolim, Goa – 403801, India'),('20230209161518426','Nashik','dvijaypharma@gmail.com','9876543212','Dvijay Pharma Pvt Ltd','422001','2022-02-05','Medicine Tower, Opp. NDCC Bank, CBS, Nashik – 422001, Maharashtra, India'),('20230209161518427','Mumbai','rahuldistributors@gmail.com','9876543213','Rahul Distributors Pvt Ltd','400031','2022-02-05','A-10/11, Royal Indl. Estate, 5B, Naigaon Cross Road, Wadala (W), Mumbai – 400031, India'),('20230209161518428','Mumbai','shubhampharmaceutical@gmail.com','9876543214','Shubham Pharmaceutical','400002','2022-02-05','Front Hall, 2nd Floor, Mimraj Building, 405, Kalbadevi Road, Mumbai – 400002, Maharashtra, India'),('20230209161518429','Mumbai','atorhealthcare@gmail.com','9876543215','Ator Healthcare Pvt. Ltd','400064','2022-02-05','Sonmur Apartments, S.V Road, Malad (W), Near Marve Road Junction, Mumbai – 400064, Maharashtra, India'),('20230209161518430','Pune','richpharma@gmail.com','9876543216','Rich Pharma India Pvt.Ltd','411030','2022-02-05','Shop No.1, Saish Apt, 963, Sadashiv Peth,');
/*!40000 ALTER TABLE `medicinedistributor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-24 13:55:02
