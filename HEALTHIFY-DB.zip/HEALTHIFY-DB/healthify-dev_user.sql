-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: healthify-dev
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `UserName` varchar(255) NOT NULL,
  `Question` varchar(255) DEFAULT NULL,
  `Answer` varchar(255) DEFAULT NULL,
  `City` varchar(255) DEFAULT NULL,
  `CreatedDate` date DEFAULT NULL,
  `EmailId` varchar(255) DEFAULT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `MobileNo` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Pincode` varchar(255) DEFAULT NULL,
  `Street` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`UserName`),
  UNIQUE KEY `UK_5ucj0efd4j5q3elidwfg1v5f` (`EmailId`),
  UNIQUE KEY `UK_44lomnm4r4bvp2e5q2rqxmqa1` (`MobileNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('amar','What was your first car?','kia carens','Pune','2022-12-01','amar@gmail.com','Amar','Wagh','9876543211','$2a$10$LUkxsgye3Pavm9p.oZwMq.pwLtuMUzpRlh5IME.j4XrgfSUadU6DG','411052','Karve Nagar','RECEPTIONIST'),('amol','What was your first car?','kia carens','Pune','2022-11-30','amol@gmail.com','Amol','Bansode','9874563210','$2a$10$64jTx3SYILq4bFuhDdA0X.yKl5fizFckxrNa2.O1Ly1EhzPnklbai','411052','Karve Nagar','DOCTOR'),('guru','What was your first car?','kia carens','Pune','2022-12-02','guru@gmail.com','Guru','Jathar','9632587410','$2a$10$W7544fd6EI2r18Hmpmwppuo7H1zF3yY2nf6pUVUIvGrLGQfnE2WHW','411052','Karve Nagar','PHARMACIST'),('ram','What is your year of birth?','1997','Pune','2022-12-01','salikramchadar@gmail.com','Ram','Chadar','7020192726','$2a$10$D4gpvgKi0aVGwvimT8/TNeF3HTnjuhvqisfLq0ISOJ.EtflEfpudG','411052','Karve Nagar','ADMIN'),('xyz','What is your year of birth?','1997','Pune','2022-11-30','xyz@gmail.com','Xyz','Zyx','9870654362','$2a$10$IxLXlip6JZxWf4amWh9JcOaUNscVeaqWFMgWYDQUhhvyERtZPmTke','411052','Karve Nagar','ADMIN'),('xyzabc','What is your year of birth?','1997','Pune','2023-04-16','xyz1@gmail.com','Xyz','Zyx','9870654363','$2a$10$qPW2BdcxGx/i2zSD/daffuyGkMM4lfqvQs6skzavU0.RvwGTTOgdS','411052','Karve Nagar','ADMIN'),('xyzac','What is your year of birth?','1997','Pune','2023-04-16','xyz12@gmail.com','Xyz','Zyx','9870654366','$2a$10$FcsywUJgMrjKYEpHT74YaufFaytT6MagNbCkAAOJ0g6rtlB86sxh.','411052','Karve Nagar','ADMIN');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-24 13:55:02
