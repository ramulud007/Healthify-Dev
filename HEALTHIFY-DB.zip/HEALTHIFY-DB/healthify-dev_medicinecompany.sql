-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: healthify-dev
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `medicinecompany`
--

DROP TABLE IF EXISTS `medicinecompany`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicinecompany` (
  `Id` varchar(255) NOT NULL,
  `City` varchar(255) NOT NULL,
  `EmailId` varchar(255) NOT NULL,
  `MobileNo` varchar(255) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Pincode` varchar(255) NOT NULL,
  `RegisterDate` date NOT NULL,
  `Street` varchar(255) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `UK_r7xoleow385nkykc6wm1qyf0q` (`EmailId`),
  UNIQUE KEY `UK_gul2ni68g4wiugrqe5wy2mdl` (`MobileNo`),
  UNIQUE KEY `UK_dc72ylf8x430e9ufcy79rrtum` (`Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicinecompany`
--

LOCK TABLES `medicinecompany` WRITE;
/*!40000 ALTER TABLE `medicinecompany` DISABLE KEYS */;
INSERT INTO `medicinecompany` VALUES ('20230807161518429','Delhi','soulnature@gmail.com','9811053751','AAA Ezee Soulnature Healthcare','110025','2023-02-05','J-195 Saket,New Delhi,17India'),('20230807161518430','Delhi','herbals@herbalsaarogya.com','6328534','Aarogya Herbals','110025','2023-02-05','K - 185/1,Surya Plaza Building, 3rd Floor,Sarai Jullena, New Friends Colony,New Delhi,110025 India'),('20230807161518431','Ahmedabad','info@aashbiotech.com','7940039971','Aash Biotech Pvt Ltd','380015','2023-02-05','417, Advait Complex,Near Sandesh Press Vastrapur,Ahmedabad,380015 India');
/*!40000 ALTER TABLE `medicinecompany` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-24 13:55:02
